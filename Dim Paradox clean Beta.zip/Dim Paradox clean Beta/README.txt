You can add your own mp3 files if you want just make sure to name them properly like they where before unless you want to modify it

Credits to PRGBQUAD-370 from GitHub.com