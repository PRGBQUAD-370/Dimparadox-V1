You can add your mp3 files for the soundboard just make sure to make them the same or else they
Won't work.